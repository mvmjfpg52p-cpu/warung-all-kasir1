# WARUNG ALL KASIR — versi awal

## Cara mencoba cepat
1. Ekstrak ZIP ini.
2. Buka `index.html` di browser komputer untuk uji fitur. Untuk iPhone, akses lewat alamat HTTPS (lihat pemasangan di bawah).
3. Tambahkan barang lewat menu **Stok**, isi harga modal, harga jual, dan stok.
4. Buka **Kasir**, tambahkan barang, masukkan uang diterima, lalu simpan penjualan.
5. Coba **Transaksi Agen** dan **Laporan**.
6. Ekspor cadangan JSON secara berkala.

## Pasang di iPhone sebagai web app
Service worker/offline PWA memerlukan HTTPS (atau localhost). Membuka file langsung dari `file://` bukan cara pemasangan PWA yang didukung.

Pilihan sederhana: unggah ketiga file (`index.html`, `manifest.json`, `sw.js`) ke hosting statis HTTPS seperti GitHub Pages, Cloudflare Pages, atau hosting web milik sendiri.
1. Buat situs statis baru dan unggah file dari folder ini.
2. Buka URL HTTPS situs tersebut di Safari pada iPhone.
3. Tekan tombol **Bagikan** di Safari → **Tambahkan ke Layar Utama** → **Tambah**.
4. Buka ikon WARUNG ALL KASIR sekali saat online agar aplikasi tersimpan untuk penggunaan offline.
5. Uji mode pesawat. Pastikan aplikasi terbuka dan data masih ada.

## Penyimpanan dan batasan
- Data transaksi dan barang disimpan di `localStorage` browser pada perangkat itu.
- Data tidak dikirim ke server dan tidak tersinkron ke perangkat lain.
- Data browser dapat hilang jika data situs dihapus, browser dibersihkan, atau perangkat bermasalah. Gunakan **Ekspor cadangan**.
- Untuk versi awal, kasir hanya mendukung pembayaran tunai penuh; belum ada retur, utang/piutang, barcode, cetak struk, akun pengguna, sinkronisasi cloud, dan pencatatan biaya operasional.
- Laporan laba adalah laba kotor berdasarkan harga modal yang tersimpan saat transaksi. Pendapatan biaya admin agen dilaporkan terpisah.
- Perubahan harga modal di stok tidak mengubah catatan modal transaksi lama.

## Keamanan
Tidak ada login atau enkripsi khusus dalam prototipe ini. Gunakan hanya pada perangkat yang Anda kendalikan dan jangan memasukkan data pelanggan yang sensitif.
